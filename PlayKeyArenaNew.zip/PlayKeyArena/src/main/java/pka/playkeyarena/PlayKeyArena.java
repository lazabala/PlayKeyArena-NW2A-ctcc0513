package pka.playkeyarena;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedList;

//user
class User {
    private String username;
    private String password;

    public User(String username, String password) {
        this.username = username;
        this.password = password;
    }

    public String getUsername() {
        return username;
    }

    public String getPassword() {
        return password;
    }
}

class Product {
    String name;
    double price;
    ImageIcon image;
    String details;

    public Product(String name, double price, ImageIcon image, String details) {
        this.name = name;
        this.price = price;
        this.image = image;
        this.details = details;
    }
}

class Transaction {
    String userName;
    String productName;
    double productPrice;

    public Transaction(String userName, String productName, double productPrice) {
        this.userName = userName;
        this.productName = productName;
        this.productPrice = productPrice;
    }
}

class Receipt {
    private ArrayList<String> productNames;
    private double totalPrice;

    public Receipt(ArrayList<String> productNames, double totalPrice) {
        this.productNames = productNames;
        this.totalPrice = totalPrice;
    }

    public ArrayList<String> getProductNames() {
        return productNames;
    }

    public double getTotalPrice() {
        return totalPrice;
    }
}

class SignUp {
    private JTextField userTextField;
    private JPasswordField passField;
    private ArrayList<User> users;  // Add users list as an instance variable

    public SignUp(JFrame parentFrame, ArrayList<User> users) {
        this.users = users;  // Initialize the users list
        JFrame signUpFrame = new JFrame("Sign Up");
        signUpFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        signUpFrame.setSize(300, 150);
        signUpFrame.setLayout(new GridLayout(3, 2));

        JLabel userLabel = new JLabel("New Username:");
        userTextField = new JTextField();

        JLabel passLabel = new JLabel("New Password:");
        passField = new JPasswordField();

        JButton signUpButton = new JButton("Sign Up");

        signUpFrame.add(userLabel);
        signUpFrame.add(userTextField);
        signUpFrame.add(passLabel);
        signUpFrame.add(passField);
        signUpFrame.add(new JLabel()); // Empty label for layout
        signUpFrame.add(signUpButton);

        signUpFrame.setVisible(true);

        signUpButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String newUsername = userTextField.getText();
                char[] newPassword = passField.getPassword();

                if (newUsername.length() > 0 && newPassword.length > 0) {
                    users.add(new User(newUsername, String.valueOf(newPassword)));
                    JOptionPane.showMessageDialog(signUpFrame, "Sign up successful! You can now log in.", "Success", JOptionPane.INFORMATION_MESSAGE);
                    signUpFrame.dispose();
                } else {
                    JOptionPane.showMessageDialog(signUpFrame, "Please enter valid username and password.", "Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        });
    }
}

public class PlayKeyArena {

    private static ArrayList<Product> products = new ArrayList<>();
    private static LinkedList<Transaction> transactions = new LinkedList<>();
    private static ArrayList<User> users = new ArrayList<>();
    
    public static void main(String[] args) {
        initializeProducts();
//C:/Users/Hi Hp/Documents/NetBeansProjects/PlayKeyArena/src/main/java/Images/bg1.jpg
        SwingUtilities.invokeLater(() -> {
            JFrame loginFrame = new JFrame("Login");
            loginFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            loginFrame.setSize(500, 400);
            loginFrame.setLayout(new GridLayout(3, 2));
            
            JLabel userLabel = new JLabel("Username:");
            JTextField userTextField = new JTextField();

            JLabel passLabel = new JLabel("Password:");
            JPasswordField passField = new JPasswordField();

            JButton loginButton = new JButton("Login");
            JButton signUpButton = new JButton("Sign Up");

            loginFrame.add(userLabel);
            loginFrame.add(userTextField);
            loginFrame.add(new JLabel()); // Empty label for layout
            loginFrame.add(passLabel);
            loginFrame.add(passField);
            loginFrame.add(new JLabel());
            loginFrame.add(signUpButton);
            

            loginButton.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    String username = userTextField.getText();
                    char[] password = passField.getPassword();

                    if (authenticateUser(username, password)) {
                        loginFrame.dispose();
                        openPlayKeyArena(username);
                    } else {
                        JOptionPane.showMessageDialog(loginFrame, "Invalid credentials. Please try again.", "Login Failed", JOptionPane.ERROR_MESSAGE);
                        passField.setText("");
                    }
                }
            });

            signUpButton.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    new SignUp(loginFrame, users);
                }
            });
            
            loginFrame.add(loginButton);

            loginFrame.setVisible(true);
        });
    }

    private static boolean authenticateUser(String username, char[] password) {
    for (User user : users) {
        if (user.getUsername().equals(username) && user.getPassword().equals(String.valueOf(password))) {
            return true; // Authentication successful
        }
    }
    return false; // Authentication failed
}

    private static void showDetails(Product product) {
        JOptionPane.showMessageDialog(null, "Details for " + product.name + ":\n" + product.details, "Game Details", JOptionPane.INFORMATION_MESSAGE);
    }

    
    private static void openPlayKeyArena(String username) {
        JFrame frame = new JFrame("PlayKeyArena - Welcome, " + username);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(600, 400);
    
        JButton displayProductsButton = new JButton("Display Products");
        JButton purchaseProductButton = new JButton("Purchase Product");
        JButton displayTransactionsButton = new JButton("Display Transactions");

        JPanel productPanel = new JPanel();
        productPanel.setLayout(new GridLayout(0, 4));
        JScrollPane productScrollPane = new JScrollPane(productPanel);

        JPanel buttonPanel = new JPanel();
        buttonPanel.add(displayProductsButton);
        buttonPanel.add(purchaseProductButton);
        buttonPanel.add(displayTransactionsButton);
        
        
        for (Product product : products) {
            ImageIcon resizedImage = resizeImageIcon(product.image, 100, 100);

            JLabel productLabel = new JLabel("<html><b>" + product.name + "</b><br>Price: $" + product.price + "</html>");
            productLabel.setIcon(resizedImage);

            JButton detailsButton = new JButton("Details");
            detailsButton.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    showDetails(product);
                }
            });

            JPanel productPanelItem = new JPanel();
            productPanelItem.setLayout(new BorderLayout());
            productPanelItem.add(productLabel, BorderLayout.CENTER);
            productPanelItem.add(detailsButton, BorderLayout.SOUTH);

            productPanel.add(productPanelItem);
        }

        frame.getContentPane().setLayout(new BorderLayout());
        frame.getContentPane().add(buttonPanel, BorderLayout.NORTH);
        frame.getContentPane().add(productScrollPane, BorderLayout.CENTER);
        
        
        displayProductsButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                displayProducts(productPanel);
            }
        });

        purchaseProductButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                purchaseProduct(frame, username);
            }
        });

        displayTransactionsButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                displayTransactions(username);
            }
        });

        frame.setVisible(true);
    }
    private static void initializeProducts() {
        ImageIcon gameAImage = new ImageIcon("C:/Users/Hi Hp/Documents/NetBeansProjects/PlayKeyArena/src/main/java/Images/cs2.jpg");
        ImageIcon gameBImage = new ImageIcon("C:/Users/Hi Hp/Documents/NetBeansProjects/PlayKeyArena/src/main/java/Images/dota2.jfif");
        ImageIcon gameCImage = new ImageIcon("C:/Users/Hi Hp/Documents/NetBeansProjects/PlayKeyArena/src/main/java/Images/league.jfif");
        ImageIcon gameDImage = new ImageIcon("C:/Users/Hi Hp/Documents/NetBeansProjects/PlayKeyArena/src/main/java/Images/hogwarts.PNG");
        ImageIcon gameEImage = new ImageIcon("C:/Users/Hi Hp/Documents/NetBeansProjects/PlayKeyArena/src/main/java/Images/bg3.PNG");
        ImageIcon gameFImage = new ImageIcon("C:/Users/Hi Hp/Documents/NetBeansProjects/PlayKeyArena/src/main/java/Images/tek.PNG");
        ImageIcon gameGImage = new ImageIcon("C:/Users/Hi Hp/Documents/NetBeansProjects/PlayKeyArena/src/main/java/Images/dl.PNG");
        ImageIcon gameHImage = new ImageIcon("C:/Users/Hi Hp/Documents/NetBeansProjects/PlayKeyArena/src/main/java/Images/sf6.PNG");
        ImageIcon gameIImage = new ImageIcon("C:/Users/Hi Hp/Documents/NetBeansProjects/PlayKeyArena/src/main/java/Images/tok.PNG");
        ImageIcon gameJImage = new ImageIcon("C:/Users/Hi Hp/Documents/NetBeansProjects/PlayKeyArena/src/main/java/Images/swjs.PNG");

        products.add(new Product("Counter Strike 2", 29.99, gameAImage, "Details about Game A..."));
        products.add(new Product("Dota 2", 19.99, gameBImage, "Details about Game B..."));
        products.add(new Product("League of Legends", 39.99, gameCImage, "Details about Game C..."));
        products.add(new Product("Hogwarts Legacy", 49.99, gameDImage, "Details about Game D..."));
        products.add(new Product("Battlegrounds 3", 59.99, gameEImage, "Details about Game E..."));
        products.add(new Product("Tekken 8", 29.99, gameFImage, "Details about Game F..."));
        products.add(new Product("Dying Light", 29.99, gameGImage, "Details about Game G..."));
        products.add(new Product("Street Fighter 6", 29.99, gameHImage, "Details about Game H..."));
        products.add(new Product("The Legend of Zelda: Tears of the Kingdom", 19.99, gameIImage, "Details about Game I..."));
        products.add(new Product("Star Wars Jedi Survivor", 39.99, gameJImage, "Details about Game J..."));

        bubbleSort(products);
    }

    private static void bubbleSort(ArrayList<Product> productList) {
        int n = productList.size();
        for (int i = 0; i < n - 1; i++) {
            for (int j = 0; j < n - i - 1; j++) {
                if (productList.get(j).name.compareTo(productList.get(j + 1).name) > 0) {
                    Collections.swap(productList, j, j + 1);
                }
            }
        }
    }

    private static void displayProducts(JPanel productPanel) {
        productPanel.revalidate();
        productPanel.repaint();
    }

    private static ImageIcon resizeImageIcon(ImageIcon originalImage, int width, int height) {
        Image image = originalImage.getImage();
        Image newImage = image.getScaledInstance(width, height, Image.SCALE_SMOOTH);
        return new ImageIcon(newImage);
    }

    private static void purchaseProduct(JFrame parentFrame, String userName) {
        
        if (userName != null) {
            JPanel productPanel = (JPanel) ((JScrollPane) parentFrame.getContentPane().getComponent(1)).getViewport().getView();
            displayProducts(productPanel);

            String productName = JOptionPane.showInputDialog(parentFrame, "Enter the name of the product you want to purchase:");
            if (productName != null) {
                double productPrice = getProductPrice(productName);

                if (isProductValid(productName)) {
        transactions.add(new Transaction(userName, productName, productPrice));
        JOptionPane.showMessageDialog(parentFrame, "Purchase successful!", "Success", JOptionPane.INFORMATION_MESSAGE);
        displayTransactions(userName); // Display user-specific transactions
    } else {
                    JOptionPane.showMessageDialog(parentFrame, "Invalid product. Please enter a valid product name.", "Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        }
    }

    private static double getProductPrice(String productName) {
        for (Product product : products) {
            if (product.name.equalsIgnoreCase(productName)) {
                return product.price;
            }
        }
        return 0.0;
    }

    // Update the generateRandomOrderReceipt method to accept the user's name
private static Receipt generateRandomOrderReceipt(String userName) {
    ArrayList<String> randomProductNames = new ArrayList<>();
    double totalPrice = 0.0;

    // Shuffle the transactions list to get random products bought by the user
    Collections.shuffle(transactions);

    for (Transaction transaction : transactions) {
        // Check if the transaction belongs to the specified user
        if (transaction.userName.equalsIgnoreCase(userName)) {
            randomProductNames.add(transaction.productName);
            totalPrice += transaction.productPrice;
        }
    }

    return new Receipt(randomProductNames, totalPrice);
}

// Update the displayTransactions method to use the user's name when generating the receipt
private static void displayTransactions(String userName) {
    Receipt userOrderReceipt = generateRandomOrderReceipt(userName);
    String receiptDetails = getTransactionsString(userName) + "\n\nUser Order Receipt:\n" +
            "Product Names: " + userOrderReceipt.getProductNames() + "\n" +
            "Total Price: $" + userOrderReceipt.getTotalPrice();

    JOptionPane.showMessageDialog(null, receiptDetails, "User Order Receipt", JOptionPane.INFORMATION_MESSAGE);
}

    private static boolean isProductValid(String productName) {
        for (Product product : products) {
            if (product.name.equalsIgnoreCase(productName)) {
                return true;
            }
        }
        return false;
    }

    
    // Update the getTransactionsString method to use the user's name
private static String getTransactionsString(String userName) {
    StringBuilder transactionsString = new StringBuilder("Transaction History for " + userName + ":\n");
    for (Transaction transaction : transactions) {
        if (transaction.userName.equalsIgnoreCase(userName)) {
            transactionsString.append("Product: ").append(transaction.productName).append("\n");
        }
    }
    return transactionsString.toString();
}

    private static String getTransactionsString() {
        StringBuilder transactionsString = new StringBuilder("Transaction History:\n");
        for (Transaction transaction : transactions) {
            transactionsString.append("User: ").append(transaction.userName).append(", Product: ").append(transaction.productName).append("\n");
        }
        return transactionsString.toString();
    }
    
    
}
